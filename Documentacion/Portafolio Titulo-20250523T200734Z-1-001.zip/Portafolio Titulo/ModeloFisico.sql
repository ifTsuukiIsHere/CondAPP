--Usuarios.

CREATE TABLE Usuario (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    contraseña VARCHAR(255),
    tipo_usuario ENUM('vecino', 'administrador') NOT NULL
);

--Anuncios.

CREATE TABLE Anuncio (
    id_anuncio INT PRIMARY KEY AUTO_INCREMENT,
    id_admin INT,
    titulo VARCHAR(100),
    contenido TEXT,
    fecha_publicacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_admin) REFERENCES Usuario(id_usuario)
);

--Reportes.

CREATE TABLE Reporte (
    id_reporte INT PRIMARY KEY AUTO_INCREMENT,
    id_vecino INT,
    titulo VARCHAR(100),
    descripcion TEXT,
    estado ENUM('pendiente', 'en proceso', 'resuelto') DEFAULT 'pendiente',
    fecha_reporte DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_vecino) REFERENCES Usuario(id_usuario)
);

--Productos a la venta.

CREATE TABLE Producto (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    id_vendedor INT,
    nombre VARCHAR(100),
    descripcion TEXT,
    precio DECIMAL(10,2),
    disponible BOOLEAN DEFAULT TRUE,
    fecha_publicacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_vendedor) REFERENCES Usuario(id_usuario)
);

--Chat en vivo.

CREATE TABLE ChatLog (
    id_log INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    mensaje TEXT,
    canal VARCHAR(50) DEFAULT 'Chat-general', 
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario)
);

--Encuestas.

CREATE TABLE Encuesta (
    id_encuesta INT PRIMARY KEY AUTO_INCREMENT,
    id_admin INT,
    pregunta TEXT,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_admin) REFERENCES Usuario(id_usuario)
);

CREATE TABLE OpcionEncuesta (
    id_opcion INT PRIMARY KEY AUTO_INCREMENT,
    id_encuesta INT,
    texto_opcion VARCHAR(200),
    FOREIGN KEY (id_encuesta) REFERENCES Encuesta(id_encuesta)
);

CREATE TABLE Voto (
    id_voto INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    id_opcion INT,
    fecha_voto DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario),
    FOREIGN KEY (id_opcion) REFERENCES OpcionEncuesta(id_opcion)
);
